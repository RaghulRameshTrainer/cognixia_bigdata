def addition(x,y):
    return x+y

def subraction(x,y):
    return x-y

def division(x,y):
    return x/y

def multiplication(x,y):
    return x*y

import logging
logging.basicConfig(filename="logfiles.log",level=logging.DEBUG)
lg=logging.getLogger()

a=100
b=200

res=addition(a,b)
lg.debug('Addition of {} + {} = {}'.format(a,b,res))
res=subraction(a,b)
lg.debug('Subraction of {} - {} = {}'.format(a,b,res))
res=division(a,b)
lg.debug('Division of {} / {} = {}'.format(a,b,res))
res=multiplication(a,b)
lg.debug('Multiplication of {} * {} = {}'.format(a,b,res))