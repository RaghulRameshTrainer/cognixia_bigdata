'''
4 clauses
try
except
else
finally
'''
try:
    with open('days.txt','r') as raghul:
        print(raghul.read())
    age=int(input('Enter your age:'))
    if age < 0 or age > 100:
        raise ValueError('Age should be between 0-100')
    age+=1
    print("Next year you age will be ", age)
except FileNotFoundError as e:
    print('Received an error while reading the file', e)
except TypeError as e:
    print('Got Type ERROR.',e)
except ValueError as e:
    print(e)
except Exception as e:
    print('Unknown Error Received.',e)
else:
    print('I am from ELSE clause')
finally:
    print("I ALWAYS RUN : FINALLY")
print('NEXT LINE')