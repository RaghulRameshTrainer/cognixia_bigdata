import logging
'''
5 built in levels are
DEBUG       10
INFO        20
WARNING     30
ERROR       40
CRITICAL    50
'''
log_format="%(levelname)s %(asctime)s  - %(message)s"
logging.basicConfig(filename='output.log',
                    level=logging.DEBUG,
                    format=log_format,
                    filemode='w')
logger=logging.getLogger()

logger.debug("This is a debug message")
logger.info("This is a info message")
logger.warning("This is a warning message")
logger.error("This is a error message")
logger.critical("This is a critical message")