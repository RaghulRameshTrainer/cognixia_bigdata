import re

'''
Functions in regex
match
search
findall
sub
split
compile-finditer
'''

line='pet:cat I love cat pet:dog I love dog'
# #matches=re.match('pet:cat',line)
# matches=re.match('pet:.{3}',line)
# print(matches.group(0))

# matches=re.search('pet:.{3}',line)
# print(matches.group(0))

#matches=re.findall('PET:.{3}',line,re.I)
#print(matches)

#print(re.sub('Love','Like',line,re.I))

#mystr='Chennai-Bangalore-Hyderabad-Pune-Mumbai-Delhi'
#print(re.split('-',mystr))


mystr="""
abcdefghijklmnopqrstuvwzyz
ABCDEFGHIJKLMNOPQRSTUVWXYZ
1234567890

Ha HaHa

~!@#$%^&*()_+

https://www.cognixia.com
http://www.amazon.com
https://google.com
https://www.cognixia.co.in

762-432-5546
323_453_2232
221 212 1211
122.424.2111

raghulramesh@gmail.com
raghul_ramesh@yahoo.com
raghul.ramesh@outlook.com
ramesh@hotmail.com

+91-9898766199
9898766199
98987661119
989876666
8898766199
7898766199
6898766199
5898766199
4898766199
3898766199
2898766199
1898766199
"""
pattern=re.compile(r'(\+91\-)?\b[6789]\d{9}\b')
#pattern=re.compile('(\w+\.)?\w+@\w+\.com')
#pattern=re.compile(r'\d{3}[-_\s]\d{3}[\s_-]\d{4}\b')
#pattern=re.compile('.')
#pattern=re.compile('https?://(w{3}\.)?\w+\.com?(\.in)?')
result=pattern.finditer(mystr)
for x in result:
    print(x.group(0))