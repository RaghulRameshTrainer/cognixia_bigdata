import sys

print("LENGTH:", len(sys.argv))
if len(sys.argv) < 2 and  len(sys.argv) > 3:
    print("USAGE IS : {} {} {}".format(sys.argv[0], "<custname>", "<acctno>"))
    print("Please rerun with custname and acctno or with custname passed")
    sys.exit(0)

print("The program name is : ", sys.argv[0])
print("Customer name is : ", sys.argv[1])
if sys.argv[2] != '':
    print("Account number is : ", sys.argv[2])