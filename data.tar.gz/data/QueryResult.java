// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Sun Sep 18 11:15:49 IST 2016
// For connector: org.apache.sqoop.manager.DirectMySQLManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  protected ResultSet __cur_result_set;
  private Integer master_custid;
  public Integer get_master_custid() {
    return master_custid;
  }
  public void set_master_custid(Integer master_custid) {
    this.master_custid = master_custid;
  }
  public QueryResult with_master_custid(Integer master_custid) {
    this.master_custid = master_custid;
    return this;
  }
  private String firstname;
  public String get_firstname() {
    return firstname;
  }
  public void set_firstname(String firstname) {
    this.firstname = firstname;
  }
  public QueryResult with_firstname(String firstname) {
    this.firstname = firstname;
    return this;
  }
  private String city;
  public String get_city() {
    return city;
  }
  public void set_city(String city) {
    this.city = city;
  }
  public QueryResult with_city(String city) {
    this.city = city;
    return this;
  }
  private Integer detail_custid;
  public Integer get_detail_custid() {
    return detail_custid;
  }
  public void set_detail_custid(Integer detail_custid) {
    this.detail_custid = detail_custid;
  }
  public QueryResult with_detail_custid(Integer detail_custid) {
    this.detail_custid = detail_custid;
    return this;
  }
  private java.sql.Date createdt;
  public java.sql.Date get_createdt() {
    return createdt;
  }
  public void set_createdt(java.sql.Date createdt) {
    this.createdt = createdt;
  }
  public QueryResult with_createdt(java.sql.Date createdt) {
    this.createdt = createdt;
    return this;
  }
  private String fulladdress;
  public String get_fulladdress() {
    return fulladdress;
  }
  public void set_fulladdress(String fulladdress) {
    this.fulladdress = fulladdress;
  }
  public QueryResult with_fulladdress(String fulladdress) {
    this.fulladdress = fulladdress;
    return this;
  }
  private String category;
  public String get_category() {
    return category;
  }
  public void set_category(String category) {
    this.category = category;
  }
  public QueryResult with_category(String category) {
    this.category = category;
    return this;
  }
  private java.sql.Date transactiondt;
  public java.sql.Date get_transactiondt() {
    return transactiondt;
  }
  public void set_transactiondt(java.sql.Date transactiondt) {
    this.transactiondt = transactiondt;
  }
  public QueryResult with_transactiondt(java.sql.Date transactiondt) {
    this.transactiondt = transactiondt;
    return this;
  }
  private Integer transactamt;
  public Integer get_transactamt() {
    return transactamt;
  }
  public void set_transactamt(Integer transactamt) {
    this.transactamt = transactamt;
  }
  public QueryResult with_transactamt(Integer transactamt) {
    this.transactamt = transactamt;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.master_custid == null ? that.master_custid == null : this.master_custid.equals(that.master_custid));
    equal = equal && (this.firstname == null ? that.firstname == null : this.firstname.equals(that.firstname));
    equal = equal && (this.city == null ? that.city == null : this.city.equals(that.city));
    equal = equal && (this.detail_custid == null ? that.detail_custid == null : this.detail_custid.equals(that.detail_custid));
    equal = equal && (this.createdt == null ? that.createdt == null : this.createdt.equals(that.createdt));
    equal = equal && (this.fulladdress == null ? that.fulladdress == null : this.fulladdress.equals(that.fulladdress));
    equal = equal && (this.category == null ? that.category == null : this.category.equals(that.category));
    equal = equal && (this.transactiondt == null ? that.transactiondt == null : this.transactiondt.equals(that.transactiondt));
    equal = equal && (this.transactamt == null ? that.transactamt == null : this.transactamt.equals(that.transactamt));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.master_custid == null ? that.master_custid == null : this.master_custid.equals(that.master_custid));
    equal = equal && (this.firstname == null ? that.firstname == null : this.firstname.equals(that.firstname));
    equal = equal && (this.city == null ? that.city == null : this.city.equals(that.city));
    equal = equal && (this.detail_custid == null ? that.detail_custid == null : this.detail_custid.equals(that.detail_custid));
    equal = equal && (this.createdt == null ? that.createdt == null : this.createdt.equals(that.createdt));
    equal = equal && (this.fulladdress == null ? that.fulladdress == null : this.fulladdress.equals(that.fulladdress));
    equal = equal && (this.category == null ? that.category == null : this.category.equals(that.category));
    equal = equal && (this.transactiondt == null ? that.transactiondt == null : this.transactiondt.equals(that.transactiondt));
    equal = equal && (this.transactamt == null ? that.transactamt == null : this.transactamt.equals(that.transactamt));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.master_custid = JdbcWritableBridge.readInteger(1, __dbResults);
    this.firstname = JdbcWritableBridge.readString(2, __dbResults);
    this.city = JdbcWritableBridge.readString(3, __dbResults);
    this.detail_custid = JdbcWritableBridge.readInteger(4, __dbResults);
    this.createdt = JdbcWritableBridge.readDate(5, __dbResults);
    this.fulladdress = JdbcWritableBridge.readString(6, __dbResults);
    this.category = JdbcWritableBridge.readString(7, __dbResults);
    this.transactiondt = JdbcWritableBridge.readDate(8, __dbResults);
    this.transactamt = JdbcWritableBridge.readInteger(9, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.master_custid = JdbcWritableBridge.readInteger(1, __dbResults);
    this.firstname = JdbcWritableBridge.readString(2, __dbResults);
    this.city = JdbcWritableBridge.readString(3, __dbResults);
    this.detail_custid = JdbcWritableBridge.readInteger(4, __dbResults);
    this.createdt = JdbcWritableBridge.readDate(5, __dbResults);
    this.fulladdress = JdbcWritableBridge.readString(6, __dbResults);
    this.category = JdbcWritableBridge.readString(7, __dbResults);
    this.transactiondt = JdbcWritableBridge.readDate(8, __dbResults);
    this.transactamt = JdbcWritableBridge.readInteger(9, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(master_custid, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(firstname, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(city, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeInteger(detail_custid, 4 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeDate(createdt, 5 + __off, 91, __dbStmt);
    JdbcWritableBridge.writeString(fulladdress, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(category, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeDate(transactiondt, 8 + __off, 91, __dbStmt);
    JdbcWritableBridge.writeInteger(transactamt, 9 + __off, 4, __dbStmt);
    return 9;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(master_custid, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(firstname, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(city, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeInteger(detail_custid, 4 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeDate(createdt, 5 + __off, 91, __dbStmt);
    JdbcWritableBridge.writeString(fulladdress, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(category, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeDate(transactiondt, 8 + __off, 91, __dbStmt);
    JdbcWritableBridge.writeInteger(transactamt, 9 + __off, 4, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.master_custid = null;
    } else {
    this.master_custid = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.firstname = null;
    } else {
    this.firstname = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.city = null;
    } else {
    this.city = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.detail_custid = null;
    } else {
    this.detail_custid = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.createdt = null;
    } else {
    this.createdt = new Date(__dataIn.readLong());
    }
    if (__dataIn.readBoolean()) { 
        this.fulladdress = null;
    } else {
    this.fulladdress = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.category = null;
    } else {
    this.category = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.transactiondt = null;
    } else {
    this.transactiondt = new Date(__dataIn.readLong());
    }
    if (__dataIn.readBoolean()) { 
        this.transactamt = null;
    } else {
    this.transactamt = Integer.valueOf(__dataIn.readInt());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.master_custid) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.master_custid);
    }
    if (null == this.firstname) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, firstname);
    }
    if (null == this.city) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, city);
    }
    if (null == this.detail_custid) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.detail_custid);
    }
    if (null == this.createdt) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.createdt.getTime());
    }
    if (null == this.fulladdress) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, fulladdress);
    }
    if (null == this.category) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, category);
    }
    if (null == this.transactiondt) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.transactiondt.getTime());
    }
    if (null == this.transactamt) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.transactamt);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.master_custid) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.master_custid);
    }
    if (null == this.firstname) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, firstname);
    }
    if (null == this.city) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, city);
    }
    if (null == this.detail_custid) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.detail_custid);
    }
    if (null == this.createdt) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.createdt.getTime());
    }
    if (null == this.fulladdress) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, fulladdress);
    }
    if (null == this.category) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, category);
    }
    if (null == this.transactiondt) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.transactiondt.getTime());
    }
    if (null == this.transactamt) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.transactamt);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 44, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(master_custid==null?"999":"" + master_custid, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(firstname==null?"NA":firstname, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(city==null?"NA":city, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(detail_custid==null?"999":"" + detail_custid, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(createdt==null?"999":"" + createdt, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(fulladdress==null?"NA":fulladdress, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(category==null?"NA":category, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(transactiondt==null?"999":"" + transactiondt, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(transactamt==null?"999":"" + transactamt, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(master_custid==null?"999":"" + master_custid, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(firstname==null?"NA":firstname, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(city==null?"NA":city, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(detail_custid==null?"999":"" + detail_custid, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(createdt==null?"999":"" + createdt, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(fulladdress==null?"NA":fulladdress, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(category==null?"NA":category, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(transactiondt==null?"999":"" + transactiondt, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(transactamt==null?"999":"" + transactamt, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 44, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.master_custid = null; } else {
      this.master_custid = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.firstname = null; } else {
      this.firstname = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.city = null; } else {
      this.city = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.detail_custid = null; } else {
      this.detail_custid = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.createdt = null; } else {
      this.createdt = java.sql.Date.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.fulladdress = null; } else {
      this.fulladdress = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.category = null; } else {
      this.category = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.transactiondt = null; } else {
      this.transactiondt = java.sql.Date.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.transactamt = null; } else {
      this.transactamt = Integer.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.master_custid = null; } else {
      this.master_custid = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.firstname = null; } else {
      this.firstname = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.city = null; } else {
      this.city = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.detail_custid = null; } else {
      this.detail_custid = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.createdt = null; } else {
      this.createdt = java.sql.Date.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.fulladdress = null; } else {
      this.fulladdress = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.category = null; } else {
      this.category = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.transactiondt = null; } else {
      this.transactiondt = java.sql.Date.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.transactamt = null; } else {
      this.transactamt = Integer.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.createdt = (o.createdt != null) ? (java.sql.Date) o.createdt.clone() : null;
    o.transactiondt = (o.transactiondt != null) ? (java.sql.Date) o.transactiondt.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.createdt = (o.createdt != null) ? (java.sql.Date) o.createdt.clone() : null;
    o.transactiondt = (o.transactiondt != null) ? (java.sql.Date) o.transactiondt.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new TreeMap<String, Object>();
    __sqoop$field_map.put("master_custid", this.master_custid);
    __sqoop$field_map.put("firstname", this.firstname);
    __sqoop$field_map.put("city", this.city);
    __sqoop$field_map.put("detail_custid", this.detail_custid);
    __sqoop$field_map.put("createdt", this.createdt);
    __sqoop$field_map.put("fulladdress", this.fulladdress);
    __sqoop$field_map.put("category", this.category);
    __sqoop$field_map.put("transactiondt", this.transactiondt);
    __sqoop$field_map.put("transactamt", this.transactamt);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("master_custid", this.master_custid);
    __sqoop$field_map.put("firstname", this.firstname);
    __sqoop$field_map.put("city", this.city);
    __sqoop$field_map.put("detail_custid", this.detail_custid);
    __sqoop$field_map.put("createdt", this.createdt);
    __sqoop$field_map.put("fulladdress", this.fulladdress);
    __sqoop$field_map.put("category", this.category);
    __sqoop$field_map.put("transactiondt", this.transactiondt);
    __sqoop$field_map.put("transactamt", this.transactamt);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if ("master_custid".equals(__fieldName)) {
      this.master_custid = (Integer) __fieldVal;
    }
    else    if ("firstname".equals(__fieldName)) {
      this.firstname = (String) __fieldVal;
    }
    else    if ("city".equals(__fieldName)) {
      this.city = (String) __fieldVal;
    }
    else    if ("detail_custid".equals(__fieldName)) {
      this.detail_custid = (Integer) __fieldVal;
    }
    else    if ("createdt".equals(__fieldName)) {
      this.createdt = (java.sql.Date) __fieldVal;
    }
    else    if ("fulladdress".equals(__fieldName)) {
      this.fulladdress = (String) __fieldVal;
    }
    else    if ("category".equals(__fieldName)) {
      this.category = (String) __fieldVal;
    }
    else    if ("transactiondt".equals(__fieldName)) {
      this.transactiondt = (java.sql.Date) __fieldVal;
    }
    else    if ("transactamt".equals(__fieldName)) {
      this.transactamt = (Integer) __fieldVal;
    }
    else {
      throw new RuntimeException("No such field: " + __fieldName);
    }
  }
  public boolean setField0(String __fieldName, Object __fieldVal) {
    if ("master_custid".equals(__fieldName)) {
      this.master_custid = (Integer) __fieldVal;
      return true;
    }
    else    if ("firstname".equals(__fieldName)) {
      this.firstname = (String) __fieldVal;
      return true;
    }
    else    if ("city".equals(__fieldName)) {
      this.city = (String) __fieldVal;
      return true;
    }
    else    if ("detail_custid".equals(__fieldName)) {
      this.detail_custid = (Integer) __fieldVal;
      return true;
    }
    else    if ("createdt".equals(__fieldName)) {
      this.createdt = (java.sql.Date) __fieldVal;
      return true;
    }
    else    if ("fulladdress".equals(__fieldName)) {
      this.fulladdress = (String) __fieldVal;
      return true;
    }
    else    if ("category".equals(__fieldName)) {
      this.category = (String) __fieldVal;
      return true;
    }
    else    if ("transactiondt".equals(__fieldName)) {
      this.transactiondt = (java.sql.Date) __fieldVal;
      return true;
    }
    else    if ("transactamt".equals(__fieldName)) {
      this.transactamt = (Integer) __fieldVal;
      return true;
    }
    else {
      return false;    }
  }
}
