// ORM class for table 'credits_pst'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Mon Jun 27 11:56:58 IST 2022
// For connector: org.apache.sqoop.manager.MySQLManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class credits_pst extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  protected ResultSet __cur_result_set;
  private Integer id;
  public Integer get_id() {
    return id;
  }
  public void set_id(Integer id) {
    this.id = id;
  }
  public credits_pst with_id(Integer id) {
    this.id = id;
    return this;
  }
  private Integer lmt;
  public Integer get_lmt() {
    return lmt;
  }
  public void set_lmt(Integer lmt) {
    this.lmt = lmt;
  }
  public credits_pst with_lmt(Integer lmt) {
    this.lmt = lmt;
    return this;
  }
  private Integer sex;
  public Integer get_sex() {
    return sex;
  }
  public void set_sex(Integer sex) {
    this.sex = sex;
  }
  public credits_pst with_sex(Integer sex) {
    this.sex = sex;
    return this;
  }
  private Integer edu;
  public Integer get_edu() {
    return edu;
  }
  public void set_edu(Integer edu) {
    this.edu = edu;
  }
  public credits_pst with_edu(Integer edu) {
    this.edu = edu;
    return this;
  }
  private Integer marital;
  public Integer get_marital() {
    return marital;
  }
  public void set_marital(Integer marital) {
    this.marital = marital;
  }
  public credits_pst with_marital(Integer marital) {
    this.marital = marital;
    return this;
  }
  private Integer age;
  public Integer get_age() {
    return age;
  }
  public void set_age(Integer age) {
    this.age = age;
  }
  public credits_pst with_age(Integer age) {
    this.age = age;
    return this;
  }
  private Integer pay;
  public Integer get_pay() {
    return pay;
  }
  public void set_pay(Integer pay) {
    this.pay = pay;
  }
  public credits_pst with_pay(Integer pay) {
    this.pay = pay;
    return this;
  }
  private Integer billamt;
  public Integer get_billamt() {
    return billamt;
  }
  public void set_billamt(Integer billamt) {
    this.billamt = billamt;
  }
  public credits_pst with_billamt(Integer billamt) {
    this.billamt = billamt;
    return this;
  }
  private Integer defaulter;
  public Integer get_defaulter() {
    return defaulter;
  }
  public void set_defaulter(Integer defaulter) {
    this.defaulter = defaulter;
  }
  public credits_pst with_defaulter(Integer defaulter) {
    this.defaulter = defaulter;
    return this;
  }
  private Integer issuerid1;
  public Integer get_issuerid1() {
    return issuerid1;
  }
  public void set_issuerid1(Integer issuerid1) {
    this.issuerid1 = issuerid1;
  }
  public credits_pst with_issuerid1(Integer issuerid1) {
    this.issuerid1 = issuerid1;
    return this;
  }
  private Integer issuerid2;
  public Integer get_issuerid2() {
    return issuerid2;
  }
  public void set_issuerid2(Integer issuerid2) {
    this.issuerid2 = issuerid2;
  }
  public credits_pst with_issuerid2(Integer issuerid2) {
    this.issuerid2 = issuerid2;
    return this;
  }
  private String tz;
  public String get_tz() {
    return tz;
  }
  public void set_tz(String tz) {
    this.tz = tz;
  }
  public credits_pst with_tz(String tz) {
    this.tz = tz;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof credits_pst)) {
      return false;
    }
    credits_pst that = (credits_pst) o;
    boolean equal = true;
    equal = equal && (this.id == null ? that.id == null : this.id.equals(that.id));
    equal = equal && (this.lmt == null ? that.lmt == null : this.lmt.equals(that.lmt));
    equal = equal && (this.sex == null ? that.sex == null : this.sex.equals(that.sex));
    equal = equal && (this.edu == null ? that.edu == null : this.edu.equals(that.edu));
    equal = equal && (this.marital == null ? that.marital == null : this.marital.equals(that.marital));
    equal = equal && (this.age == null ? that.age == null : this.age.equals(that.age));
    equal = equal && (this.pay == null ? that.pay == null : this.pay.equals(that.pay));
    equal = equal && (this.billamt == null ? that.billamt == null : this.billamt.equals(that.billamt));
    equal = equal && (this.defaulter == null ? that.defaulter == null : this.defaulter.equals(that.defaulter));
    equal = equal && (this.issuerid1 == null ? that.issuerid1 == null : this.issuerid1.equals(that.issuerid1));
    equal = equal && (this.issuerid2 == null ? that.issuerid2 == null : this.issuerid2.equals(that.issuerid2));
    equal = equal && (this.tz == null ? that.tz == null : this.tz.equals(that.tz));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof credits_pst)) {
      return false;
    }
    credits_pst that = (credits_pst) o;
    boolean equal = true;
    equal = equal && (this.id == null ? that.id == null : this.id.equals(that.id));
    equal = equal && (this.lmt == null ? that.lmt == null : this.lmt.equals(that.lmt));
    equal = equal && (this.sex == null ? that.sex == null : this.sex.equals(that.sex));
    equal = equal && (this.edu == null ? that.edu == null : this.edu.equals(that.edu));
    equal = equal && (this.marital == null ? that.marital == null : this.marital.equals(that.marital));
    equal = equal && (this.age == null ? that.age == null : this.age.equals(that.age));
    equal = equal && (this.pay == null ? that.pay == null : this.pay.equals(that.pay));
    equal = equal && (this.billamt == null ? that.billamt == null : this.billamt.equals(that.billamt));
    equal = equal && (this.defaulter == null ? that.defaulter == null : this.defaulter.equals(that.defaulter));
    equal = equal && (this.issuerid1 == null ? that.issuerid1 == null : this.issuerid1.equals(that.issuerid1));
    equal = equal && (this.issuerid2 == null ? that.issuerid2 == null : this.issuerid2.equals(that.issuerid2));
    equal = equal && (this.tz == null ? that.tz == null : this.tz.equals(that.tz));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.id = JdbcWritableBridge.readInteger(1, __dbResults);
    this.lmt = JdbcWritableBridge.readInteger(2, __dbResults);
    this.sex = JdbcWritableBridge.readInteger(3, __dbResults);
    this.edu = JdbcWritableBridge.readInteger(4, __dbResults);
    this.marital = JdbcWritableBridge.readInteger(5, __dbResults);
    this.age = JdbcWritableBridge.readInteger(6, __dbResults);
    this.pay = JdbcWritableBridge.readInteger(7, __dbResults);
    this.billamt = JdbcWritableBridge.readInteger(8, __dbResults);
    this.defaulter = JdbcWritableBridge.readInteger(9, __dbResults);
    this.issuerid1 = JdbcWritableBridge.readInteger(10, __dbResults);
    this.issuerid2 = JdbcWritableBridge.readInteger(11, __dbResults);
    this.tz = JdbcWritableBridge.readString(12, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.id = JdbcWritableBridge.readInteger(1, __dbResults);
    this.lmt = JdbcWritableBridge.readInteger(2, __dbResults);
    this.sex = JdbcWritableBridge.readInteger(3, __dbResults);
    this.edu = JdbcWritableBridge.readInteger(4, __dbResults);
    this.marital = JdbcWritableBridge.readInteger(5, __dbResults);
    this.age = JdbcWritableBridge.readInteger(6, __dbResults);
    this.pay = JdbcWritableBridge.readInteger(7, __dbResults);
    this.billamt = JdbcWritableBridge.readInteger(8, __dbResults);
    this.defaulter = JdbcWritableBridge.readInteger(9, __dbResults);
    this.issuerid1 = JdbcWritableBridge.readInteger(10, __dbResults);
    this.issuerid2 = JdbcWritableBridge.readInteger(11, __dbResults);
    this.tz = JdbcWritableBridge.readString(12, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(id, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(lmt, 2 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(sex, 3 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(edu, 4 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(marital, 5 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(age, 6 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(pay, 7 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(billamt, 8 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(defaulter, 9 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(issuerid1, 10 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(issuerid2, 11 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(tz, 12 + __off, 12, __dbStmt);
    return 12;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(id, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(lmt, 2 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(sex, 3 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(edu, 4 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(marital, 5 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(age, 6 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(pay, 7 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(billamt, 8 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(defaulter, 9 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(issuerid1, 10 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(issuerid2, 11 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(tz, 12 + __off, 12, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.id = null;
    } else {
    this.id = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.lmt = null;
    } else {
    this.lmt = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.sex = null;
    } else {
    this.sex = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.edu = null;
    } else {
    this.edu = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.marital = null;
    } else {
    this.marital = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.age = null;
    } else {
    this.age = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.pay = null;
    } else {
    this.pay = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.billamt = null;
    } else {
    this.billamt = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.defaulter = null;
    } else {
    this.defaulter = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.issuerid1 = null;
    } else {
    this.issuerid1 = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.issuerid2 = null;
    } else {
    this.issuerid2 = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.tz = null;
    } else {
    this.tz = Text.readString(__dataIn);
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.id) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.id);
    }
    if (null == this.lmt) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.lmt);
    }
    if (null == this.sex) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.sex);
    }
    if (null == this.edu) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.edu);
    }
    if (null == this.marital) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.marital);
    }
    if (null == this.age) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.age);
    }
    if (null == this.pay) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.pay);
    }
    if (null == this.billamt) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.billamt);
    }
    if (null == this.defaulter) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.defaulter);
    }
    if (null == this.issuerid1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.issuerid1);
    }
    if (null == this.issuerid2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.issuerid2);
    }
    if (null == this.tz) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, tz);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.id) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.id);
    }
    if (null == this.lmt) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.lmt);
    }
    if (null == this.sex) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.sex);
    }
    if (null == this.edu) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.edu);
    }
    if (null == this.marital) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.marital);
    }
    if (null == this.age) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.age);
    }
    if (null == this.pay) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.pay);
    }
    if (null == this.billamt) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.billamt);
    }
    if (null == this.defaulter) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.defaulter);
    }
    if (null == this.issuerid1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.issuerid1);
    }
    if (null == this.issuerid2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.issuerid2);
    }
    if (null == this.tz) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, tz);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 44, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(id==null?"null":"" + id, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(lmt==null?"null":"" + lmt, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(sex==null?"null":"" + sex, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(edu==null?"null":"" + edu, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(marital==null?"null":"" + marital, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(age==null?"null":"" + age, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(pay==null?"null":"" + pay, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(billamt==null?"null":"" + billamt, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(defaulter==null?"null":"" + defaulter, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(issuerid1==null?"null":"" + issuerid1, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(issuerid2==null?"null":"" + issuerid2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(tz==null?"null":tz, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(id==null?"null":"" + id, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(lmt==null?"null":"" + lmt, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(sex==null?"null":"" + sex, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(edu==null?"null":"" + edu, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(marital==null?"null":"" + marital, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(age==null?"null":"" + age, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(pay==null?"null":"" + pay, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(billamt==null?"null":"" + billamt, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(defaulter==null?"null":"" + defaulter, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(issuerid1==null?"null":"" + issuerid1, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(issuerid2==null?"null":"" + issuerid2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(tz==null?"null":tz, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 44, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.id = null; } else {
      this.id = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.lmt = null; } else {
      this.lmt = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.sex = null; } else {
      this.sex = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.edu = null; } else {
      this.edu = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.marital = null; } else {
      this.marital = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.age = null; } else {
      this.age = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.pay = null; } else {
      this.pay = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.billamt = null; } else {
      this.billamt = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.defaulter = null; } else {
      this.defaulter = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.issuerid1 = null; } else {
      this.issuerid1 = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.issuerid2 = null; } else {
      this.issuerid2 = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.tz = null; } else {
      this.tz = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.id = null; } else {
      this.id = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.lmt = null; } else {
      this.lmt = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.sex = null; } else {
      this.sex = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.edu = null; } else {
      this.edu = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.marital = null; } else {
      this.marital = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.age = null; } else {
      this.age = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.pay = null; } else {
      this.pay = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.billamt = null; } else {
      this.billamt = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.defaulter = null; } else {
      this.defaulter = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.issuerid1 = null; } else {
      this.issuerid1 = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.issuerid2 = null; } else {
      this.issuerid2 = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.tz = null; } else {
      this.tz = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    credits_pst o = (credits_pst) super.clone();
    return o;
  }

  public void clone0(credits_pst o) throws CloneNotSupportedException {
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new TreeMap<String, Object>();
    __sqoop$field_map.put("id", this.id);
    __sqoop$field_map.put("lmt", this.lmt);
    __sqoop$field_map.put("sex", this.sex);
    __sqoop$field_map.put("edu", this.edu);
    __sqoop$field_map.put("marital", this.marital);
    __sqoop$field_map.put("age", this.age);
    __sqoop$field_map.put("pay", this.pay);
    __sqoop$field_map.put("billamt", this.billamt);
    __sqoop$field_map.put("defaulter", this.defaulter);
    __sqoop$field_map.put("issuerid1", this.issuerid1);
    __sqoop$field_map.put("issuerid2", this.issuerid2);
    __sqoop$field_map.put("tz", this.tz);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("id", this.id);
    __sqoop$field_map.put("lmt", this.lmt);
    __sqoop$field_map.put("sex", this.sex);
    __sqoop$field_map.put("edu", this.edu);
    __sqoop$field_map.put("marital", this.marital);
    __sqoop$field_map.put("age", this.age);
    __sqoop$field_map.put("pay", this.pay);
    __sqoop$field_map.put("billamt", this.billamt);
    __sqoop$field_map.put("defaulter", this.defaulter);
    __sqoop$field_map.put("issuerid1", this.issuerid1);
    __sqoop$field_map.put("issuerid2", this.issuerid2);
    __sqoop$field_map.put("tz", this.tz);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if ("id".equals(__fieldName)) {
      this.id = (Integer) __fieldVal;
    }
    else    if ("lmt".equals(__fieldName)) {
      this.lmt = (Integer) __fieldVal;
    }
    else    if ("sex".equals(__fieldName)) {
      this.sex = (Integer) __fieldVal;
    }
    else    if ("edu".equals(__fieldName)) {
      this.edu = (Integer) __fieldVal;
    }
    else    if ("marital".equals(__fieldName)) {
      this.marital = (Integer) __fieldVal;
    }
    else    if ("age".equals(__fieldName)) {
      this.age = (Integer) __fieldVal;
    }
    else    if ("pay".equals(__fieldName)) {
      this.pay = (Integer) __fieldVal;
    }
    else    if ("billamt".equals(__fieldName)) {
      this.billamt = (Integer) __fieldVal;
    }
    else    if ("defaulter".equals(__fieldName)) {
      this.defaulter = (Integer) __fieldVal;
    }
    else    if ("issuerid1".equals(__fieldName)) {
      this.issuerid1 = (Integer) __fieldVal;
    }
    else    if ("issuerid2".equals(__fieldName)) {
      this.issuerid2 = (Integer) __fieldVal;
    }
    else    if ("tz".equals(__fieldName)) {
      this.tz = (String) __fieldVal;
    }
    else {
      throw new RuntimeException("No such field: " + __fieldName);
    }
  }
  public boolean setField0(String __fieldName, Object __fieldVal) {
    if ("id".equals(__fieldName)) {
      this.id = (Integer) __fieldVal;
      return true;
    }
    else    if ("lmt".equals(__fieldName)) {
      this.lmt = (Integer) __fieldVal;
      return true;
    }
    else    if ("sex".equals(__fieldName)) {
      this.sex = (Integer) __fieldVal;
      return true;
    }
    else    if ("edu".equals(__fieldName)) {
      this.edu = (Integer) __fieldVal;
      return true;
    }
    else    if ("marital".equals(__fieldName)) {
      this.marital = (Integer) __fieldVal;
      return true;
    }
    else    if ("age".equals(__fieldName)) {
      this.age = (Integer) __fieldVal;
      return true;
    }
    else    if ("pay".equals(__fieldName)) {
      this.pay = (Integer) __fieldVal;
      return true;
    }
    else    if ("billamt".equals(__fieldName)) {
      this.billamt = (Integer) __fieldVal;
      return true;
    }
    else    if ("defaulter".equals(__fieldName)) {
      this.defaulter = (Integer) __fieldVal;
      return true;
    }
    else    if ("issuerid1".equals(__fieldName)) {
      this.issuerid1 = (Integer) __fieldVal;
      return true;
    }
    else    if ("issuerid2".equals(__fieldName)) {
      this.issuerid2 = (Integer) __fieldVal;
      return true;
    }
    else    if ("tz".equals(__fieldName)) {
      this.tz = (String) __fieldVal;
      return true;
    }
    else {
      return false;    }
  }
}
